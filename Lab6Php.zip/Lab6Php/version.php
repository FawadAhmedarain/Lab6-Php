<?php 
 phpinfo();
?>