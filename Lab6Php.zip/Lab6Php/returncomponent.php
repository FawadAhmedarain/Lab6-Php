<?php
$url = 'http://sw.muet.edu.pk/faculty/cvs/sample.pdf	';
$url=parse_url($url);
echo 'Scheme : '.$url['scheme']."\n";
echo "<br>";
echo 'Host : '.$url['host']."\n";
echo "<br>";
echo 'Path : '.$url['path']."\n";
?>