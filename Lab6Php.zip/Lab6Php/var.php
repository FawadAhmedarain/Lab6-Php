<?php
$a = 'PHPlab6';
?>

<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title><?php echo $a; ?> Php !</title>
  </head>

  <body>
  	
  <h3><?php echo $a; ?></h3>
  <p>This the lab 6 Task7 part(b)</p>
  <p><a href="http://localhost/var.php">Go to the <?php echo $a; ?></a>.</p>
</body>
</html>